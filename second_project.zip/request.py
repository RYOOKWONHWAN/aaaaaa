import requests
import json
import jsonify
import pandas as pd
import numpy as np
import warnings
from movie_recommend import get_recommendations
from titlesim import titlesimdef
from userrecommend import userrecommenddef

from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import CountVectorizer

warnings.filterwarnings('ignore')


def recommend(user_id):
    print("추천알고리즘 시작")
    watchedlist = [502356, 594767, 640146]

    df_list = []
    titlesim_list = []
    for i in watchedlist:
        recommendations = get_recommendations(i)
        titlesim = titlesimdef(i)
        titlesim_list = titlesim_list+titlesim
        df_list.append(recommendations)

    merged_df = pd.concat(df_list, ignore_index=True)

    recommend_df = merged_df.sort_values("weighted_vote", ascending=False)
    new_recommend_df = recommend_df.drop_duplicates(
        subset=['movie_id'], keep='first')[0:10]

    recommend_json = new_recommend_df['movie_id'].to_list()
    print(recommend_json)
    values_only_title = list(set(titlesim_list))
    user_rec_list = userrecommenddef(user_id).tolist()
    return_data = {"recommendbygenre": recommend_json,
                   "titlesim": values_only_title, "userrecommend": user_rec_list}
    print("추천알고리즘 끝")
    return return_data


url = 'http://localhost:8090/recommendtest'
data = recommend(11)
print(data)
headers = {'Content-type': 'application/json'}
print("--------------------------------")
print("요청 전송")
response = requests.post(url, data=json.dumps(data), headers=headers)

print(response.text)
