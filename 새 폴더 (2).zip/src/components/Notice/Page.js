import React, { useState } from 'react';
import { PageItem, Pagination } from 'react-bootstrap';


const Page = () => {
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;
    const totalItems = 100;

    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = [];

    for (let i = 1; i <= totalPages; i++) {
        pageNumbers.push(
            <PageItem key={i} active={i === currentPage} onClick={() => setCurrentPage(i)}>
                {i}
            </PageItem>
        );
    }

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = Array.from({ length: itemsPerPage }, (_, i) => `Item ${indexOfFirstItem + i + 1}`);

    return (
        <div className="App">
            <ul>
                {currentItems.map((item) => (
                    <li key={item}>{item}</li>
                ))}
            </ul>
            <Pagination>{pageNumbers}</Pagination>
        </div>
    );
}
export default Page