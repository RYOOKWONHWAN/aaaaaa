import { useCallback, useState } from 'react';
import { Container, Form, FormGroup, Label, Input, Button, Col, Row } from 'reactstrap';
import { useDropzone } from 'react-dropzone';
import axios from 'axios';
import { } from 'reactstrap';
import { baseUrl } from 'Apiurl';

import Editf from './Editf';
function NoticePage() {

    const author = localStorage.getItem("adminName")


    const [notices, setNotices] = useState({
        admin_id: localStorage.getItem("adminId"),
        title: '',
        content: '',
        upload: null
    }


    );
    const onDrop = useCallback((acceptedFiles) => {
        // 파일이 업로드될 때 실행되는 콜백 함수입니다.
        // 업로드된 파일 객체를 upload 상태값에 저장합니다.
        setNotices({
            ...notices,
            upload: acceptedFiles[0], // 여러 개의 파일을 업로드하려면 for문 등을 사용해야 합니다.
        });
    }, []);

    const { getRootProps, getInputProps } = useDropzone({ onDrop });

    const handleValueChange = (e) => {
        //radio버튼에서는 e.preventDefault()를 하면 더블 클릭을 해줘야 한다.
        //e.preventDefault();

        setNotices({ ...notices, [e.target.name]: e.target.value });

    };

    const config = {
        headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: localStorage.getItem("Authorization"),
        },
    };
    const onSubmit = async (event) => {
        event.preventDefault();
        // 공지사항을 서버에 전송하는 로직을 작성합니다.
        // 업로드한 파일 정보도 함께 전송할 수 있습니다.
        const formData = new FormData();

        formData.append('file', notices.upload);
        await axios.post(`${baseUrl}/noticewrite`, formData, config)
            .then(response => {
                console.log("요청보냄")
            })
            .catch(error => {

                // 요청이 실패한 경우 실행될 코드
            });
        // fetch 또는 axios 등을 사용하여 formData를 전송합니다.
    };

    return <>
        <Container className="d-flex justify-content-center align-items-center" style={{ height: '100vh', width: 900 }}>

            <div>
                <Row>
                    <Col style={{
                        textAlign: 'center'
                    }}>
                        <h2>공지사항 작성</h2>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <Form onSubmit={onSubmit}>
                            <Editf></Editf>
                            <FormGroup>
                                <Label for="title">제목</Label>
                                <Input
                                    type="text"
                                    name="title"
                                    onChange={handleValueChange}
                                    style={{ width: '600px' }}
                                />
                            </FormGroup>
                            <FormGroup>
                                <Label for="author">작성자</Label>
                                <Input
                                    type="text"
                                    name="author"

                                    style={{ width: '600px' }}
                                    defaultValue={author}
                                    readOnly
                                />
                            </FormGroup>
                            <FormGroup>
                                <Label for="content">내용</Label>
                                <Input
                                    type="textarea"
                                    name="content"
                                    onChange={handleValueChange}

                                />
                            </FormGroup>

                            <Button type="submit">작성</Button>
                        </Form>
                    </Col>
                </Row>
            </div >

        </Container >

    </>


}

export default NoticePage;
