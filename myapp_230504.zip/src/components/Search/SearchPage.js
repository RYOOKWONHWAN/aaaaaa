import SearchList from "./SearchList";
import "assets/css/font.css";
import "assets/css/movielist.css";

const SearchPage = () => {
  return (
    <div>
      <SearchList />
    </div>
  );
};

export default SearchPage;
