import axios from 'axios'
import MovieList from 'components/Index/MovieList';
import { useEffect, useState } from 'react'

const Recommend = () => {
    console.log("recommend")
    const config = {
        headers: {
            "Content-Type": "application/json",
            Authorization: localStorage.getItem("Authorization"),
        },
    };

    const [movies, setMovies] = useState([]);
    useEffect(() => {
        axios.post("http://localhost:8090/recommendtest", config)
            .then((response) => {
                console.log(response.data)
                setMovies(response.data)
            })
            .catch(error => {
                console.log(error);
            });
    }, []);
    return (
        <>
            <div style={{ marginLeft: '5%', marginRight: '5%' }}>
                <MovieList listTitle="평점 높은 최신영화 리스트" movies={movies} />
                <MovieList listTitle="평점 높은 고전영화 리스트" movies={movies} />
            </div>
        </>

    )
}

export default Recommend