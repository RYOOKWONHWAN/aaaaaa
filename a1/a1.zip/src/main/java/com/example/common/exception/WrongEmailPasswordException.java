package com.example.common.exception;

public class WrongEmailPasswordException extends RuntimeException {
	
	public WrongEmailPasswordException() {
		
	}

}//end class
