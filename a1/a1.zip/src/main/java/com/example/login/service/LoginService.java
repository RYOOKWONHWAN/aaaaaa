package com.example.login.service;

public interface LoginService {

}
